require('./bootstrap');

import App from "./components/App.vue";
