<?php

namespace App\Models;

class Globals
{

    public static $USER_ROLE = 'USER';
    public static $ADMIN_ROLE = 'ADMIN';

}
