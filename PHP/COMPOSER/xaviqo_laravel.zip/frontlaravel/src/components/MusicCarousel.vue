<template>

</template>

<script>
export default {
  name: "MusicCarousel"
}
</script>

<style scoped>

</style>