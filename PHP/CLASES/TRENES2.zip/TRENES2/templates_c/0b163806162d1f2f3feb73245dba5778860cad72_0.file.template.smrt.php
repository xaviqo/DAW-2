<?php
/* Smarty version 4.2.1, created on 2022-11-27 18:14:07
  from '/home/xavi/Desktop/TRABAJOS/DAW-2/PHP/CLASES/TRENES2/template.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63839adfdf3b59_96049852',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0b163806162d1f2f3feb73245dba5778860cad72' => 
    array (
      0 => '/home/xavi/Desktop/TRABAJOS/DAW-2/PHP/CLASES/TRENES2/template.tpl',
      1 => 1669568833,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63839adfdf3b59_96049852 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <center>
        Hola, me llamo <?php echo $_smarty_tpl->tpl_vars['nombre']->value;?>

    </center>
</body>
</html><?php }
}
