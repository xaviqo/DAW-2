<!DOCTYPE html>
<head>
    <title>Formularios</title>
    <style>
        input {
            margin: 15px;
        }
    </style>
</head>
<body>
    <form action="accion.php" method="GET">
        <input type="text" name="name"></input>
        <input type="text" name="id"></input>
        <br/>
        <input type="submit" value="send">
    </form>
</body>
</html>