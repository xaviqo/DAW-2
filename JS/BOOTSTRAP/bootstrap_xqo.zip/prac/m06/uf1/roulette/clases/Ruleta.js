export default class Ruleta{

    _resultats;
    _numero;

    constructor(){
        this._resultats = [];
    }

    jugar(aposta){
        
    }

    getNumero(){
        this._numero;
    }

    getResultats(){
        this._resultats;
    }

    girar(){
        return Math.round(Math.random() * 37);
    }




}