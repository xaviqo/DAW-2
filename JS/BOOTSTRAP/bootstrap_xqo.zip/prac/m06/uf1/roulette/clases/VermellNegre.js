import Apuesta from "./Apuesta";

export default class VermellNegre extends Apuesta {

    constructor(diners,valor){
        super(diners,valor);
    }
    
}