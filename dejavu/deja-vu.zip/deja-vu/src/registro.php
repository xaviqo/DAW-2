<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/background.css">
    <link rel="stylesheet" href="../css/fonts.css">
    <link rel="stylesheet" href="../css/login-registro.css">
    <link rel="stylesheet" href="../css/registro.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <script src="../js/registro.js"></script>
</head>

<body>
    <div class="caja-input-flex">
        <div class="caja-blanca">
            <div class="flex-center-content">
                <h1>REGÍSTRATE</h1>
            </div>

            <form action="registro_.php" method="post" onsubmit="return validateRegistro();">
                <div class="group">
                <div>
                        <div class="outterLabel">
                            <label>Nombre</label>
                            <div id="msg-js-nombre" class="js-msg"></div>
                        </div>
                        <input autocomplete="off" name="nombre" id="nombre" class="input" type="text" required>
                    </div>
                    <div>
                        <div class="outterLabel">
                            <label>Correo Electrónico</label>
                            <div id="msg-js-email" class="js-msg"></div>
                        </div>
                        <input autocomplete="off" name="email" id="email" class="input" type="email" required>
                    </div>
                    <div>
                        <div class="outterLabel">
                            <label>Contraseña</label>
                            <div id="msg-js-password" class="js-msg"></div>
                        </div>
                        <input autocomplete="off" name="passwd" id="passwd" class="input" type="password" required>
                    </div>
                    <div class="cp-telefono">
                        <div>
                            <div class="outterLabel">
                                <label for="postal">Código Postal</label>
                                <div id="msg-js-postal" class="js-msg"></div>
                            </div>
                            <input autocomplete="off" name="postal" id="postal" class="input" type="number" required>
                        </div>
                        <div>
                            <div class="outterLabel">
                                <label for="phone">Teléfono</label>
                                <div id="msg-js-phone" class="js-msg"></div>
                            </div>
                            <input autocomplete="off" name="phone" id="phone" class="input" type="number" required>
                        </div>
                    </div>
                    <div>
                        <div class="outterLabel">
                            <label>Dirección</label>
                            <div id="msg-js-direccion" class="js-msg"></div>
                        </div>
                        <input autocomplete="off" name="direccion" id="direccion" class="input" type="text" required>
                    </div>
                </div>
                <br>
                <br>
                <div class="botones-form-registro flex-center-content">
                        <button id="reset-btn">Reiniciar</button>
                        <input id="signup-btn" type="submit" value="Registro">
                </div>
            </form>
        </div>
        <div class="caja-verde">
            <div class="img-registro">
                <img src="../imagenes/Dèjá_vú_4_-removebg-preview.png" alt="logo">
            </div>
        </div>
    </div>
</body>

</html>