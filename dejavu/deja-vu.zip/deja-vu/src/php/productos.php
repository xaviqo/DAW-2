<?php

@include 'header.php';

?>
<div class="contenedor">

<h3 class="title"> Nustros pizzas</h3>
<div class="contenedorPord">
    <div class="producto" data-name="Producto1">
        <img src="/src/imagenes/ImagenProductos/unnamed (1).jpg" alt="">
        <h3>Pizza Margarita</h3>
        <div class="precio">$20</div>

    </div>



    <div class="producto" data-name="Producto2">
        <img src="/src/imagenes/ImagenProductos/unnamed (2).jpg" alt="">
        <h3>Pizza peperoni</h3>
        <div class="precio">$20</div>
    </div>


    <div class="producto" data-name="Producto2">
        <img src="/src/imagenes/ImagenProductos/unnamed (3).jpg" alt="">
        <h3>Pizza peperoni</h3>
        <div class="precio">$20</div>
    </div>


    <div class="producto" data-name="Producto2">
        <img src="/src/imagenes/ImagenProductos/unnamed (4).jpg" alt="">
        <h3>Pizza peperoni</h3>
        <div class="precio">$20</div>
    </div>

    <div class="producto" data-name="Producto2">
        <img src="/src/imagenes/ImagenProductos/unnamed (5).jpg" alt="">
        <h3>Pizza peperoni</h3>
        <div class="precio">$20</div>
    </div>

    <div class="producto" data-name="Producto2">
        <img src="/src/imagenes/ImagenProductos/unnamed (1).jpg" alt="">
        <h3>Pizza peperoni</h3>
        <div class="precio">$20</div>
    </div>


</div>
</div>

<?php

@include 'footer.php';

?>