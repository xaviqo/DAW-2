<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/fonts.css">
    <link rel="stylesheet" href="../css/Login.css">

</head>

<body>
    <div class="login">
        <div class="caja-blanca">
            <h1>INICIA SESIÓN</h1>

            <form action="conexionBdLogin.php" method="post">
                <div class="group">
                    <label class="label">Correo electrónico o usuario</label>
                    <input autocomplete="off" name="email" id="email" class="input" type="email" required>
                    <label class="label">Contraseña</label>
                    <input autocomplete="off" name="passwd" id="passwd" class="input" type="password" required>

                </div>
                <br>
                <br>

                <button> Login</button>
            </form>
        </div>
        <div class="caja-verde">
            <div class="img_caja_verde">
                <img src="../imagenes/Dèjá_vú_4_-removebg-preview.png" alt="logo">
            </div>
            <div class="sub_img">
                <hr>
                <h4>¿Aún no estás registrado?</h4>

                <button><a href="registate.html">Regístrate</a></button>
            </div>
        </div>
    </div>
</body>

</html>
