<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/fonts.css">
    <link rel="stylesheet" href="../css/headerMain.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <script src="../js/headerMainUsuario.js"></script>
</head>

<body>
    <header>
        <img id="img_header" src="../imagenes/Dèjá_vú_4_-removebg-preview.png" alt="">
        <nav>

            <div id="decoracionUsuario"></div>
            <div class="usuario">
                <div id="circuloHover"></div>
                <div id="imagenUsuario">
                    <a id="imgUser" href="usuario">
                        <img id="img_2" src="../imagenes/predef_img_usuarios/2.png" alt="imagen predeterminada Usuario 2">
                    </a>
                </div>
            </div>


            <?php
            @include 'conexionBdLogin.php';

            if (isset($_SESSION['email'])) {
            }
            ?>

            <ul>
                <li><a href="home.php">HOME</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
                <li><a href="#">SOBRE NOSOTROS</a></li>
                <li><a href="login.php">LOGIN</a></li>
                <li><a href="#">CARRITO</a></li>

            </ul>


        </nav>
    </header>