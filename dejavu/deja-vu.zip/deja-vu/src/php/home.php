<?php
session_start();
@include 'headerMain.php';


?>

<section class="contenido">
    <div class="principal">
        <div class="comida">
            <img src="../imagenes/ImagenComida.jpg" alt="">
        </div>
        <div class="logo">
            <img src="../imagenes/logo_2.png" alt="">
        </div>
        <div class="texto">
            <img src="../imagenes/DКjа_vг_3_-removebg-preview.png" alt="">
        </div>
        <h1 class="titulo">NUESTRAS MEJORES PIZZAS</h1>
        <div class="pizzas">
            <img src="../imagenes/img_fondo_pag_princp(cuerpo).png" alt="" class="tirabuzon">
            <div class="dejavecu">
                <h2 class="pizza1">Déjà vecú</h2>
                <img src="../imagenes/pizza_carne_pimientos.png" alt="">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos neque, minus nesciunt culpa id quod. In debitis labore blanditiis nesciunt laudantium repellat, commodi soluta est at ea incidunt explicabo adipisci.
                    Assumenda ut natus laborum laudantium iste error aspernatur ipsa nisi incidunt ullam atque saepe facilis culpa blanditiis laboriosam illum dolores doloremque vero iusto iure, at amet perferendis provident ea! Dicta!</p>
            </div>
            <div class="dejasenti">
                <h2 class="pizza2">Déjà sentí</h2>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis eveniet quas odit voluptate sunt delectus quia. Temporibus quas error laudantium iure autem reprehenderit. Corrupti in non dolore placeat tempore iusto.
                    Exercitationem debitis deleniti enim ea tempora id iure consectetur. Veniam eligendi itaque veritatis ut mollitia voluptate quibusdam, magnam impedit deserunt dolores enim, quam esse, similique nemo consequuntur. Veritatis, quam! Rem.</p>
                <img src="../imagenes/Pizza_setas_olivas.png" alt="">
            </div>
            <div class="dejavisite">
                <h2 class="pizza3">Déjà visité</h2>
                <img src="../imagenes/pizza_ensalada.png" alt="">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro esse architecto atque non accusamus vitae, delectus, molestiae fugiat obcaecati ea, culpa dolorem at inventore odio mollitia a ipsam assumenda expedita!
                    Assumenda beatae, reprehenderit qui commodi distinctio consequatur, exercitationem similique nostrum accusamus ullam quis suscipit magni. Sit velit libero architecto, eum magnam quam reprehenderit itaque eaque ullam, ab repudiandae, cum blanditiis?</p>
            </div>
        </div>
    </div>
</section>

<?php

@include 'footer.php';

?>