<?php

session_start();


if (isset($_REQUEST['email']) && isset($_REQUEST['passwd'])) {

    $db = new PDO('mysql:host=db;dbname=DejaVu', 'mysql', '1234');

    //TODO si quieres hacerlo con una sola consulta, tendrás que meter la consula en un array, 
    //hacer un push a una variable y en los ifs, comprobar en 0 del array y el 1.

    $stmt1 = $db->prepare("select correo from usuarios WHERE correo = '" . $_REQUEST['email'] . "' ;");
    $stmt2 = $db->prepare("select passwd from usuarios WHERE passwd = '" . $_REQUEST['passwd'] . "' ;");

    $stmt1->execute();
    $stmt2->execute();

    $resultado_correo = $stmt1->fetch();
    $resultado_passwd = $stmt2->fetch();

    $_SESSION['email'] =  $resultado_correo;
    $_SESSION['passwd'] = $resultado_passwd;


    if ($_REQUEST['email'] === $resultado_correo['correo'] && $_REQUEST['passwd'] === $resultado_passwd['passwd']) {
        // echo 'El usuario existe!';
        header("Location: ../php/home.php");
    } else {
        echo 'El usuario no existe!';
    }
}
