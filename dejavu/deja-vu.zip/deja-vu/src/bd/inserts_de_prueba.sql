INSERT INTO usuarios (usuario, correo,passwd) VALUES
('HectorR', 'HectorR@gmail.com', '1234');

INSERT INTO usuarios (usuario, correo,passwd) VALUES
('Victoria', 'VictoriaFernanda@gmail.com', '12345');