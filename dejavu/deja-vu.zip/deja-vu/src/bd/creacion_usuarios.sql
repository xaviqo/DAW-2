

DROP TABLE usuarios;

