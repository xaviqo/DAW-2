<?php

@include 'header.php';

?>
<h1 id="titulo">CONTACTANOS</h1>
    <h2>Correo</h2>
    <p>correo@gmail.com</p>
    <h2>Telefono</h2>
    <div class="imagen"><img src="../imagenes/índice.jpeg" alt=""></div>
    <p>+34 638492012</p>
    <h2>Horario</h2>
    <table>
        <tr>
            <td>Lunes</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Martes</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Miercoles</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Jueves</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Viernes</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Sabado</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
        <tr>
            <td>Domingo</td>
            <td>8:00 - 13:00<br>
                16:00 - 19:00
            </td>
        </tr>
    </table>
    <h2>Direccion</h2>
    <p>Avenida Ramon 145 AB, Sabadell, Barcelona</p>
    <h2 id="posicion">¿DONDE ESTAMOS?</h2>
    <div class="mapa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2584.3230083950793!2d2.1038232491528945!3d41.551829675389655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4954e8980376d%3A0x228496620571376d!2sNou%20Sabadell%20Sol!5e0!3m2!1ses!2ses!4v1667499380271!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    <?php
    
    @include 'footer.php';
    
    ?>