<?php
require './db.php';

if (
    isset($_REQUEST['nombre']) &&
    isset($_REQUEST['email']) &&
    isset($_REQUEST['passwd']) &&
    isset($_REQUEST['postal']) &&
    isset($_REQUEST['phone']) &&
    isset($_REQUEST['direccion'])
) {

    //comprobamos si ya existe el correo
    $select_existe_correo = $db->prepare("SELECT usuario FROM usuarios WHERE correo = '".$_REQUEST['email']."'");
    $select_existe_correo->execute();
    $existe_correo = $select_existe_correo->fetch();

    //al poner una excepción, si ya existe el mail paramos la ejecución del script
    if ($existe_correo){
        throw new Exception("Correo electrónico ya registrado");
    }

    //introducirmos en la tabla usuarios
    $insert_nuevo_usuario = $db->prepare("INSERT INTO usuarios VALUES 
    (NULL,'".$_REQUEST['nombre']."','".$_REQUEST['email']."','".$_REQUEST['passwd']."')");
    $insert_nuevo_usuario->execute();

    //recuperamos el nuevo identificador para hacer la relación en la tabla de información del usuario
    $select_id_nuevo_usuario = $db->prepare
    ("SELECT id FROM usuarios WHERE correo = '".$_REQUEST['email']."'");
    $select_id_nuevo_usuario->execute();
    $nuevo_usuario_id = $select_id_nuevo_usuario->fetch();

    //introdumos la información en la tabla de info_usuarios
    $insert_info_nuevo_usuario = $db->prepare("INSERT INTO info_usuarios VALUES 
    (".$nuevo_usuario_id['id'].",'".$_REQUEST['postal']."',".$_REQUEST['phone'].",'".$_REQUEST['direccion']."')");
    $insert_info_nuevo_usuario->execute();

}
