window.onload = () => {
    let decoracion = document.getElementById('circuloHover');

    decoracion.addEventListener('mouseover', () => {
        decoracion.style.transitionDuration = '1s';
        decoracion.style.transform = 'scale(1.4)';
    });
    decoracion.addEventListener('mouseout', () => {
        decoracion.style.transitionDuration = '1s';
        decoracion.style.transform = 'scale(1)';

    });
}
