<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/background.css">
    <link rel="stylesheet" href="../css/fonts.css">
    <link rel="stylesheet" href="../css/login-registro.css">
    <link rel="stylesheet" href="../css/login.css">
</head>

<body>
    <div class="caja-input-flex">
        <div class="caja-blanca">
            <div class="flex-center-content">
                <h1>INICIA SESIÓN</h1>
            </div>

            <form action="conexionBdLogin.php" method="post">
                <div class="group">
                    <label class="label">Correo electrónico o usuario</label>
                    <input autocomplete="off" name="email" id="email" class="input" type="email" required>
                    <label class="label">Contraseña</label>
                    <input autocomplete="off" name="passwd" id="passwd" class="input" type="password" required>

                </div>
                <br>
                <br>
                <div class="flex-center-content">
                    <button>Login</button>
                </div>
            </form>
        </div>
        <div class="caja-verde">
            <div class="img-login">
                <img src="../imagenes/Dèjá_vú_4_-removebg-preview.png" alt="logo">
            </div>
            <div class="sub_img">
                <hr>
                <h4>¿Aún no estás registrado?</h4>

                <div class="flex-center-content">
                    <button><a href="registate.html">Regístrate</a></button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>