<?php

$db = getDatabase();

function getDatabase(){
    try {
        $parametros_db = 'mysql:host=db;dbname=DejaVu';
        return new PDO($parametros_db, 'mysql', '1234');
    } catch (PDOException $e) {
		  throw new PDOException($e->getMessage(), $e->getCode());			
    }
}

?>