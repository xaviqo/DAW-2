<?php

@include 'header.php';

?>
    <div class="slider">
        <ul>
            <li><img src="../imagenes/ImgenSlider/1200x680_pizzas.jpg" alt=""></li>
            <li><img src="../imagenes/ImgenSlider/Publicidad-para-pizzas.jpg" alt=""></li>
            <li><img src="../imagenes/ImgenSlider/Publicidad-para-pizzas.jpg" alt=""></li>
            <li><img src="../imagenes/ImgenSlider/tipos-de-pizzas-pepperoni.jpg.jpg" alt=""></li>
        </ul>
    </div>

    <div class="contenedor">
        <h3 class="title"> Nuestros pizzas</h3>
        <div class="contenedorPord">
            <div class="producto" data-name="Producto1">
                <img src="/src/ImagenProducto/unnamed (1).jpg" alt="">
                <h3>Pizza Margarita</h3>
                <div class="precio">$20</div>

            </div>



            <div class="producto" data-name="Producto2">
                <img src="../imagenes/ImagenProducto/unnamed (1).jpg" alt="">
                <h3>Pizza peperoni</h3>
                <div class="precio">$20</div>
            </div>


            <div class="producto" data-name="Producto2">
                <img src="../ImagenProducto/unnamed (3).jpg" alt="">
                <h3>Pizza peperoni</h3>
                <div class="precio">$20</div>
            </div>


            <div class="producto" data-name="Producto2">
                <img src="../ImagenProducto/unnamed (4).jpg" alt="">
                <h3>Pizza peperoni</h3>
                <div class="precio">$20</div>
            </div>

            <div class="producto" data-name="Producto2">
                <img src="../ImagenProducto/unnamed (5).jpg" alt="">
                <h3>Pizza peperoni</h3>
                <div class="precio">$20</div>
            </div>

            <div class="producto" data-name="Producto2">
                <img src="../ImagenProducto/unnamed.jpg" alt="">
                <h3>Pizza peperoni</h3>
                <div class="precio">$20</div>
            </div>


        </div>
    </div>

<?php

@include 'footer.php';

?>