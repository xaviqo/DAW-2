<footer>
        <ul>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque perferendis alias amet dolore architecto
                dolorum, mollitia ullam animi veniam sint assumenda vel culpa enim odio dignissimos quia fugiat
                provident ut!</li>
            <li>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum qui id provident ullam incidunt
                maxime dolorum, consequatur tempora adipisci, in perferendis! Rerum corrupti nam ea numquam porro facere
                illum vel.</li>
            <li>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consectetur hic in cum, esse omnis facilis
                delectus inventore, ullam, facere nam ipsa. Eos fugiat voluptatum rerum quas quis, saepe soluta
                veritatis.</li>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam necessitatibus cupiditate quibusdam modi
                iure quod sequi eum corporis, debitis maiores temporibus, dicta minus ratione sit maxime, voluptatibus
                quidem repudiandae beatae.</li>
            <li><a href="#">Politicas legales</a></li>
        </ul>
    </footer>
</body>

</html>